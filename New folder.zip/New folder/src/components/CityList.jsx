import React from 'react'
import '../index.css'

const CityList = props => {
    return (
        <div className='w-full bg-amber-50 text-2xl h-auto border m-1 p-3 md:pl-10 hover:shadow-lg text-gray-800 items-center md:h-20 flex flex-col md:flex-row content-center'>
            <p className='w-full md:w-1/4 bold '>{props.city}</p>
            <p className='w-full md:w-1/4'>{props.weather}</p>
            <p className='w-full md:w-1/4'>{props.temp}&deg;</p>
            <button className='w-full md:w-1/6 rounded-md h-12 p-13 text-gray-100 bg-blue-700'>show more</button>
        </div>
    )
}

export default CityList
