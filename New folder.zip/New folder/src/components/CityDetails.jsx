import axios from 'axios'
import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import weather from './../img/weather2.svg'

const CityDetails = () => {
    const city = window.location.pathname.split('/')
    const [cityData, setCityData] = useState(null)

    useEffect(() => {
        getCityData()
    }, [])

    const getCityData = async () => {
        try {
            const data = await axios.get(`https://api.openweathermap.org/data/2.5/weather?q=${city[city.length - 1]}&appid=a80bec999ed8c77b8e990b8a42ce51cc`)
            setCityData(data.data)
        } catch (error) {
        }
    }

    return (
        <div className='p-3'>
            {cityData && <div className='w-full md:w-3/4 bg-amber-50  mt-14 m-auto border rounded-md p-3 md:p-14 justify-center flex flex-col md:flex-row'>
                <img className=' w-full md:w-2/5 m-auto' src={weather} alt="weather" />
                <div>
                    <h2 className='text-xl mt-5 bold'>{`This is the ${cityData.name}'s weather details:`}</h2>
                    <br />
                    <p>{`${cityData.name} is ${cityData.weather[0].description} today!`}</p>
                    <p>{`Today the temperture is between ${cityData.main.temp_min} and ${cityData.main.temp_max}degree`}</p>
                    <p>{`Also The pressure is ${cityData.main.pressure} paskal`}</p>
                    <Link to='/'>    <button className='text-gray-100 bg-blue-700 w-full hover:shadow-lg mt-8 p-2 rounded-sm'>Back to home</button></Link>
                </div>
            </div>}
        </div>
    )
}

export default CityDetails
