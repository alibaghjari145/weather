import {useState, useEffect} from 'react'
import { Link, Routes } from 'react-router-dom';
import axios from 'axios';
import './../index.css';
import weatherImg from './../img/weather.svg'
import CityList from './CityList';
const Home=()=>{
const [cityList, setCityList] = useState([])

useEffect(() => {
  getCities()
}, [])

const getCities = async()=>{
  const cities= await axios.get('https://api.openweathermap.org/data/2.5/box/city?bbox=12,32,15,37,10&appid=a80bec999ed8c77b8e990b8a42ce51cc')
  setCityList(cities.data.list)
}
  return (
    <div  className="p-3 md:p-10 pt-20 ">
     <img className='w-full md:w-3/5 m-auto' src={weatherImg} alt="weather image" />
     {cityList.map(city=>(<Link key={city.name} to={`/city/${city.name}`}>
      <CityList  city={city.name} temp={city.main.temp} weather={city.weather[0].description} />
     </Link>
     ))}
    </div>
  );
}
export default Home
